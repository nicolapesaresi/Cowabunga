from pathlib import Path

import pygame

from cowabunga.env import settings


class TextSprite(pygame.sprite.Sprite):
    """Generic text sprite object."""

    def __init__(
        self,
        text: str,
        font: pygame.font.Font,
        color: tuple[int, int, int],
        pos: tuple[int, int],
    ):
        super().__init__()
        self.font = font
        self.color = color
        self.text = text

        self.image = self.font.render(self.text, True, self.color)
        self.rect = self.image.get_rect(topleft=pos)

    def update_text(self, new_text: str | int):
        """Updates sprite text."""
        if isinstance(new_text, int):
            new_text = str(new_text)
        self.text = new_text
        self.image = self.font.render(self.text, True, self.color)
        self.rect = self.image.get_rect(topleft=self.rect.topleft)


class TitleText(TextSprite):
    """Main menu title text sprite."""

    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.asset = Path(__file__).parent / ".." / "assets" / "textlogo.png"
        try:
            image = pygame.image.load(self.asset)
            max_width = settings.WIDTH * 0.6
            scale = max_width / image.get_width()
            image = pygame.transform.smoothscale(
                image,
                (
                    int(image.get_width() * scale),
                    int(image.get_height() * scale),
                ),
            )
            self.image = image
            self.rect = self.image.get_rect()
            self.rect.center = (settings.WIDTH // 2, int(settings.HEIGHT * 0.48))
        except Exception as e:
            print(f"Unable to load image for TitleText: {e}")
            text = "COWABUNGA"
            font = pygame.font.Font(None, size=settings.HEIGHT // 5)
            color = "yellow"
            pos = (settings.WIDTH // 2, settings.HEIGHT * 0.4)
            super().__init__(text, font, color, pos)
            # center text
            self.rect.centerx = settings.WIDTH // 2


class PressToPlayText(TextSprite):
    """Text that indiucates how to start a game."""

    def __init__(self):
        text = "Click or press enter to start a game"
        font = pygame.font.SysFont(None, settings.HEIGHT // 20, italic=True)
        color = "white"
        pos = (settings.WIDTH // 2, settings.HEIGHT * 0.65)
        super().__init__(text, font, color, pos)
        # center text
        self.rect.centerx = settings.WIDTH // 2

    def clicked(self, click_pos: tuple[int, int]) -> bool:
        """Check that a click occurred on the text.

        Args:
            click_pos: coords of the click (x, y).

        Returns:
            (bool): whether the text has been clicked.
        """
        return self.rect.collidepoint(click_pos)


class LivesSprite(TextSprite):
    """Lives counter sprite."""

    def __init__(self, text: str | int):
        if isinstance(text, int):
            text = str(text)
        font = pygame.font.Font(None, size=settings.HEIGHT // 18)
        color = "white"
        pos = (2 * settings.WIDTH // 16, settings.WIDTH // 16)
        super().__init__(text, font, color, pos)
        self.rect.centerx = pos[0]


class ScoreSprite(TextSprite):
    """Lives counter sprite."""

    def __init__(self, text: str | int):
        if isinstance(text, int):
            text = str(text)
        font = pygame.font.Font(None, size=settings.HEIGHT // 18)
        color = "yellow"
        pos = (14 * settings.WIDTH // 16, settings.WIDTH // 16)
        super().__init__(text, font, color, pos)
        self.rect.centerx = pos[0]


class GameOverText(TextSprite):
    """Game over text sprite."""

    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.asset = Path(__file__).parent / ".." / "assets" / "gameover_text.png"
        try:
            image = pygame.image.load(self.asset)
            max_width = settings.WIDTH * 0.35
            scale = max_width / image.get_width()
            image = pygame.transform.smoothscale(
                image,
                (
                    int(image.get_width() * scale),
                    int(image.get_height() * scale),
                ),
            )
            self.image = image
            self.rect = self.image.get_rect()
            self.rect.center = (settings.WIDTH // 2, int(settings.HEIGHT * 0.33))
        except Exception as e:
            print(f"Unable to load asset for GameOverText: {e}")
            text = "GAME OVER"
            font = pygame.font.Font(None, size=settings.HEIGHT // 6)
            color = "black"
            pos = (settings.WIDTH // 2, settings.HEIGHT // 3)
            super().__init__(text, font, color, pos)
            # center text
            self.rect.centerx = settings.WIDTH // 2


class FinalScoreSprite(TextSprite):
    """Final score sprite."""

    def __init__(self, text: str | int):
        if isinstance(text, int):
            text = str(text)
        font = pygame.font.Font(None, size=settings.HEIGHT // 5)
        color = "yellow"
        pos = (settings.WIDTH // 2, settings.HEIGHT * 0.55)
        super().__init__(text, font, color, pos)
        # center text
        self.rect.centerx = settings.WIDTH // 2


class PressToGoToMenuText(TextSprite):
    """Text that indicates how to go back to main menu."""

    def __init__(self):
        text = "Click or press enter to retry"
        font = pygame.font.SysFont(None, settings.HEIGHT // 20, italic=True)
        color = "white"
        pos = (settings.WIDTH // 2, settings.HEIGHT * 0.72)
        super().__init__(text, font, color, pos)
        # center text
        self.rect.centerx = settings.WIDTH // 2

    def clicked(self, click_pos: tuple[int, int]) -> bool:
        """Check that a click occurred on the text.

        Args:
            click_pos: coords of the click (x, y).

        Returns:
            (bool): whether the text has been clicked.
        """
        return self.rect.collidepoint(click_pos)


class PauseText(TextSprite):
    """Text that indicates how to go back to main menu."""

    def __init__(self):
        text = "Press the spacebar to continue"
        font = pygame.font.SysFont(None, settings.HEIGHT // 20, italic=True)
        color = "white"
        pos = (settings.WIDTH // 2, settings.HEIGHT * 0.55)
        super().__init__(text, font, color, pos)
        # center text
        self.rect.centerx = settings.WIDTH // 2


class PageTitle(TextSprite):
    """Yellow title at the top of a menu panel (sound, info and records pages)."""

    def __init__(self, text: str, center_y: float = settings.HEIGHT * 0.335):
        font = pygame.font.Font(None, settings.HEIGHT // 12)
        super().__init__(text, font, "yellow", (0, 0))
        self.rect.center = (settings.WIDTH // 2, int(center_y))
