import numpy as np

from cowabunga.env import settings
from cowabunga.env.actions import Action
from cowabunga.env.events import Event
from cowabunga.env.objects.cliff import Cliff, LeftCliff, RightCliff
from cowabunga.env.objects.cow import Cow
from cowabunga.env.objects.paddle import Paddle


class CowabungaEnv:
    """Environment for cowabunga game."""

    def __init__(self, seed: int | None = None):
        """Instantiates the class.

        Args:
            seed: seed for random cow generation.
        """
        self.seed = seed
        if self.seed is not None:
            np.random.seed(self.seed)

        self.new_cow_prob = settings.NEW_COW_PROB
        self.max_cows_on_screen = settings.MAX_COWS_ON_SCREEN
        self.cooldown = settings.ACTION_COOLDOWN
        self.reset()

    def reset(self):
        """Resets env to initial state."""
        self.lives = settings.LIVES
        self.score = 0
        self.done = False

        self.cows: list[Cow] = []
        self.cow_id = 0  # needed in pygame to update cow sprites. gets updated at every new cow
        self.cliffs: list[Cliff] = [LeftCliff(), RightCliff()]
        self.paddle = Paddle()
        self.frames_since_last_move = self.cooldown + 1  # allows moving
        self.events: list[Event] = []  # events that happened during the last step

    def step(self, action: Action):
        """Updates the environment after one instant of time.

        Args:
            action: action taken by the player. Can be NOOP (no action).

        Returns:
            obs: observation of the game by the player, corresponding to state.
            done: whether episode is finished.
            info: additional info. info["events"] lists the Event values of this step.
        """
        self.events = []
        # handle action
        if action in (Action.LEFT, Action.RIGHT) and self.frames_since_last_move >= self.cooldown:
            self.paddle.move(action)
            self.frames_since_last_move = 0
        else:
            self.frames_since_last_move += 1
            if action != Action.NOOP_DRAG:
                self.paddle.animate_move()

        ## update env
        # check collisions
        self.check_collisions()
        # update cows
        self.update_cows()
        # generate new cows
        self.generate_new_cows()
        # update state
        obs = []  # TODO: implement

        # check if game is finished
        if self.lives < 1 and not self.done:
            self.done = True
            self.events.append(Event.GAME_OVER)
        info = {"events": self.events}

        return obs, self.done, info

    def check_collisions(self):
        """Checks collisions for all the cows."""
        paddle_hitbox = self.paddle.get_hitbox()
        cliffs_hitboxes = [cliff.get_hitbox() for cliff in self.cliffs]
        for cow in self.cows:
            collided = False
            # paddle collision (bounce)
            if cow.check_landing_collision(paddle_hitbox):
                cow.bounce(paddle_hitbox[1])
                self.events.append(Event.BOUNCE)
                collided = True
            # cliff collision (land)
            if not collided:
                for cliff_hitbox in cliffs_hitboxes:
                    cliff_top = cliff_hitbox[1]
                    if cow.check_landing_collision(cliff_hitbox):
                        cow.land(cliff_top)
                        collided = True
                        break
            # apply gravity if no collision happened
            if not collided:
                cow.freefall()

    def update_cows(self):
        """Moves all cows according to their current velocity, and update score and lives."""
        for cow in self.cows:
            cow.move()
            if cow.is_dead():
                self.events.append(Event.COW_LOST)
                if self.lives > 0:
                    self.lives -= 1
            if cow.is_safe():
                self.score += 1
                self.events.append(Event.COW_SAVED)

        # remove safe and dead cows from env
        self.cows = [cow for cow in self.cows if not cow.is_dead() and not cow.is_safe()]

    def generate_new_cows(self):
        """Evaluates cows on the screen and decides wether to generate a new one."""
        n_cows = len(self.cows)
        if n_cows < self.max_cows_on_screen:  # noqa: SIM102
            if n_cows == 0 or np.random.random() < self.new_cow_prob:
                new_cow = Cow()
                new_cow.id = self.cow_id
                self.cow_id += 1
                self.cows.append(new_cow)
